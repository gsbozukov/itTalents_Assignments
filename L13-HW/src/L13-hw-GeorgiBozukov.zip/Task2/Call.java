package Task2;
public class Call {
    final static double PRICE_FOR_A_MINUTE = 0.15;
    String caller;
    String receiver;
    int duration;
}
