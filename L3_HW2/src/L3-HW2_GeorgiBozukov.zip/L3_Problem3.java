public class L3_Problem3 {
    public static void main(String[] args) {
        //All odd numbers between -10 and 10
        for (int n=-9; n<=10; n+=2){
            System.out.println(n);
        }
    }
}
