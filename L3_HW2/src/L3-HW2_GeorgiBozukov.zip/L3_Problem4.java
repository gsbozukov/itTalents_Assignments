public class L3_Problem4 {
    public static void main(String[] args) {
        //All numbers from 10 to 1 in descending order
        for (int i = 10; i>0; i--){
            System.out.print(i+" ");
        }
    }
}
