public class L3_Problem1 {
    public static void main(String[] args) {
        //Show all numbers between 1 to 100
        for (int i = 1; i <= 100 ; i++) {
            System.out.println(i);
        }
    }
}
