public class L3_Problem2 {
    public static void main(String[] args) {
        //Showing all integers between -20 and 50
        for (int i = -20; i <= 50; i++) {
            System.out.println(i);
        }
    }
}
